import java.util.Iterator;

/**
 * Created by manshu on 2/7/15.
 */
public class PriorityQueueWrapper<T extends Comparable<T>> implements Iterable<T> {
    
    public static enum queueType {
        Stack,
        Queue,
        Priority
    }
    
    private class MyItem implements Comparable<MyItem>{
        T item;
        Integer cost;
        public MyItem(T item) {
            this.item = item;
        }
        public MyItem(T item, Integer cost) {
            this.item = item;
            this.cost = cost;
        }
        public void setCost(Integer cost) {
            this.cost = cost;
        }
        @Override
        public int compareTo(MyItem o) {
            if (this.cost == 0 && o.cost == 0)
                return this.item.compareTo(o.item);
            return this.cost.compareTo(o.cost);
        }

        @Override
        public boolean equals(Object obj) {
            return item.equals((T) obj);
        }
    }
    
    MyPriorityQueue<MyItem> queue;
    Enum myQueueType;
    private int counter;
    
    public PriorityQueueWrapper(String queue_type) {
        try {
            myQueueType = queueType.valueOf(queue_type);
        } catch (IllegalArgumentException iae) {
            System.out.println("Queue Type should be correctly specified. -> " + iae.getMessage());
            System.exit(1);
        }
        queue = new MyPriorityQueue<MyItem>();
        counter = 0;
    }

    public void add(T item) {
        MyItem myItem = new MyItem(item);
        if (myQueueType == queueType.Stack)
            myItem.setCost(--counter);
        else if (myQueueType == queueType.Queue)
            myItem.setCost(++counter);
        else if (myQueueType == queueType.Priority) {
            myItem.setCost(0);
        }
        queue.add(myItem);
    }

    public T poll() {
        return queue.poll().item;
    }

    public int size() {
        return queue.size();
    }

    public boolean isEmpty() {
        return queue.isEmpty();
    }

    public T remove() {
        return queue.remove().item;
    }

    public boolean contains(T item) {
        MyItem myItem = new MyItem(item);
        return queue.contains(myItem);
    }

    @Override
    public Iterator<T> iterator() {
        final Iterator<MyItem> items = queue.iterator();
        Iterator<T> iterator = new Iterator<T>() {
            int current = 0;

            @Override
            public boolean hasNext() {
                return items.hasNext();
            }

            @Override
            public T next() {
                return items.next().item;
            }

            @Override
            public void remove() {
                return;
            }
        };
        return iterator;
    }

    public static void main(String[] args) {
        PriorityQueueWrapper<Integer> myPriorityQueue = new PriorityQueueWrapper<Integer>("Priority");
        int numInsert = 100;
        for (int i = 0; i < numInsert; i++) {
            int num = (int) (Math.random() * numInsert * 10);
            myPriorityQueue.add(num);
            System.out.println(num);
        }

        System.out.println("===========================");
        Iterator<Integer> iterator = myPriorityQueue.iterator();
        while (iterator.hasNext()) {
            System.out.print(iterator.next() + " ");
        }
        System.out.println();

        System.out.println("===========================");
        for (int i = 0; i < numInsert; i++) {
            int curr = myPriorityQueue.poll();
            System.out.println(curr);
        }
    }
}
