/**
 * Created by manshu on 2/7/15.
 */
public class Node<T> implements Comparable<Node<T>> {
    T item;
    Node<T> parent;
    int compared_cost;
    int current_cost;
    int heuristic_cost;

    Node(T item, Node<T> parent) {
        this.item = item;
        this.parent = parent;
        current_cost = 0;
        heuristic_cost = 0;
        compared_cost = 0;
    }

    @Override
    public boolean equals(Object obj) {
        Node<T> node2 = (Node<T>) obj;
        return this.item.equals(node2.item);
    }

    @Override
    public int hashCode() {
        return item.hashCode();
    }

    @Override
    public int compareTo(Node<T> o) {
        if (compared_cost > o.compared_cost)
            return 1;
        else if (compared_cost < o.compared_cost)
            return -1;
        else
            return 0;
    }
}
