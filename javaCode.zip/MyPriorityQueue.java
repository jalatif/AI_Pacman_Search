import java.util.Iterator;

/**
 * Created by manshu on 2/7/15.
 */
public class MyPriorityQueue<T extends Comparable<T>> implements Iterable<T> {
    
    private Object[] queue;
    private int size;

    public MyPriorityQueue() {
        this(2);
    }

    public MyPriorityQueue(int capacity) {
        queue = new Object[capacity];
        size = 0;
    }
    
    private Integer getParent(int i) {
        int p = (i - 1) / 2;
        if (p < 0) return null;
        return p;
    }
    
    private Integer getLeft(int i) {
        int l = 2 * i + 1;
        if (l >= size) return null;
        return l;
    }
    
    private Integer getRight(int i) {
        int r = 2 * i + 2;
        if (r >= size) return null;
        return r;
    }
    
    private void growQueue() {
        Object[] new_queue = new Object[2 * queue.length];
        for (int i = 0; i < queue.length; i++) {
            new_queue[i] = queue[i];
        }
        queue = new_queue;
    }
    
    private void heapify(int i) {
        if (i >= size) return;
        if (i < 0) return;
        
        Integer parent = getParent(i);
        if (parent == null) return;
        
        if (compareTo(queue[parent], queue[i]) > 0) {
            T temp = (T) queue[i];
            queue[i] = queue[parent];
            queue[parent] = temp;
            heapify(parent);
        }
    }
    
    private int compareTo(Object o1, Object o2) {
        T item1 = (T) o1;
        T item2 = (T) o2;
        return item1.compareTo(item2);
    }
    
    private void percolateDown(int i) {
        if (i >= size) return;
        if (i < 0) return;

        Integer l = getLeft(i);
        Integer r = getRight(i);
        
        if (l == null) return;
        
        if (l != null && r != null) {
            if (compareTo(queue[i], queue[l]) <= 0 && compareTo(queue[i], queue[r]) <= 0)  return;
            else {
                int smaller = l;
                if (compareTo(queue[l], queue[r]) > 0) smaller = r;
                T temp = (T) queue[i];
                queue[i] = queue[smaller];
                queue[smaller] = temp;
                percolateDown(smaller);
            }
        } else if (r == null) {
            if (compareTo(queue[i], queue[l]) <= 0) return;
            else {
                T temp = (T) queue[i];
                queue[i] = queue[l];
                queue[l] = temp;
                percolateDown(l);
            }
        }
    }
    
    public void add(T item) {
        if (size == queue.length) {
            growQueue();        
        }    
        queue[size++] = item;
        heapify(size - 1);
    }
    
    public T poll() {
        if (size == 0) return null;
        Object item = queue[0];
        queue[0] = queue[size - 1];
        size--;
        percolateDown(0);
        return (T) item;
    }

    public int size() {
        return size;
    }
    
    public boolean isEmpty() {
        return size == 0;
    }
    
    public T remove() {
        return poll();
    }
    
    public boolean contains(T item) {
        for (int i = 0; i < size; i++) {
            T item2 = (T)queue[i];
            if (item2.equals(item)) return true;
        }    
        return false;
    }
    
    @Override
    public Iterator<T> iterator() {
        Iterator<T> iterator = new Iterator<T>() {
            int current = 0;
            
            @Override
            public boolean hasNext() {
                return current != size;
            }

            @Override
            public T next() {
                return (T) queue[current++];
            }

            @Override
            public void remove() {
                return;
            }
        };
        return iterator;
    }


    public static void main(String[] args) {
        MyPriorityQueue<Integer> myPriorityQueue = new MyPriorityQueue<Integer>();
        int numInsert = 20;
        for (int i = 0; i < numInsert; i++) {
            int num = (int) (Math.random() * numInsert * 10);
            myPriorityQueue.add(num);
            System.out.println(num);
        }

        System.out.println("===========================");
        Iterator<Integer> iterator = myPriorityQueue.iterator();
        while (iterator.hasNext()) {
            System.out.print(iterator.next() + " ");
        }
        System.out.println();
        
        System.out.println("===========================");
        int prev = -1;
        for (int i = 0; i < numInsert; i++) {
            int curr = myPriorityQueue.poll();
            System.out.println(curr);
            if (curr < prev) {
                System.out.println("Oh no na");
                break;
            }
            prev = curr;
        }
        
    }

}
