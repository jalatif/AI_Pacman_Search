/**
 * Created by manshu on 2/7/15.
 */
public class Point {
    int x;
    int y;
    Point(int x, int y) {
        this.x = x; this.y = y;
    }

    @Override
    public String toString() {
        return "(" + x + ", " + y + ")";
    }

    @Override
    public boolean equals(Object obj) {
        Point p2 = (Point) obj;
        return p2.x == this.x && p2.y == this.y;
    }

    @Override
    public int hashCode() {
        return 31 * x + y;
    }
}
