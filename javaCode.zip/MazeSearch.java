import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/**
 * Created by manshu on 2/6/15.
 */


public class MazeSearch {

    private char maze[][];
    private final char GOAL = '.', START = 'P', WALL = '%', MARK = '|', EMPTY = ' ';
    int row_num, col_num;
    Point start, goal;
    
    public MazeSearch(String fileName) {
        try {
            readMaze(fileName);    
        } catch (IOException ie) {
            System.out.println("Cannot read maze file. -> " + ie.getMessage());
            System.exit(0);
        }
        //System.out.println(start + " " + goal);
    }
    
    public void readMaze(String fileName) throws IOException{
        BufferedReader br = new BufferedReader(new FileReader(fileName));

        ArrayList<String> readMaze = new ArrayList<String>();
        
        String line;
        while ((line = br.readLine()) != null) {
            readMaze.add(line);
        }
        if (readMaze.isEmpty()) throw new IOException("File not ok for search");
        row_num = readMaze.size();
        col_num = readMaze.get(0).length();
        maze = new char[row_num][col_num];
        
        int row = 0;
        for (String row_maze : readMaze) {
            int col = 0;
            for (int i = 0; i < row_maze.length(); i++) {
                maze[row][col] = row_maze.charAt(i);
                if (maze[row][col] == START) start = new Point(row, col);
                if (maze[row][col] == GOAL) goal = new Point(row, col);
                col++;
            }
            row++;
        }
        printAndCleanMaze();
    }
    
    private ArrayList<Point> getSuccessors(Point p) {
        ArrayList<Point> successors = new ArrayList<Point>(4);
        
        if (p.x + 1 < row_num && maze[p.x + 1][p.y] != WALL) successors.add(new Point(p.x + 1, p.y));
        if (p.y + 1 < col_num && maze[p.x][p.y + 1] != WALL) successors.add(new Point(p.x, p.y + 1));
        if (p.x - 1 >= 0 && maze[p.x - 1][p.y] != WALL) successors.add(new Point(p.x - 1, p.y));
        if (p.y - 1 >= 0 && maze[p.x][p.y - 1] != WALL) successors.add(new Point(p.x, p.y - 1));

        return successors;
    }

    private <T> T searchQueue(PriorityQueue<T> queue, T item) {
        Iterator<T> iterator = queue.iterator();
        while (iterator.hasNext()) {
            T current = iterator.next();
            if (current.equals(item)) return item;
        }
        return null;
    }
    
    private String getPriorityType(String searchStrategy) {
        if (searchStrategy.equals("dfs"))
            return "Stack";
        else if (searchStrategy.equals("bfs"))
            return "Queue";
        else
            return "Priority";
    }

    private void initCost(String searchStrategy, Node<Point> node) {
        if (searchStrategy.equals("uniform"))
            node.compared_cost = node.current_cost; 
        else if (searchStrategy.equals("greedy")) 
            node.compared_cost = node.heuristic_cost;
        else if (searchStrategy.equals("astar"))
            node.compared_cost = node.current_cost + node.heuristic_cost;
        return;
    }
    
    public void searchPath(String searchStrategy) {
        PriorityQueueWrapper<Node<Point>> frontier = new PriorityQueueWrapper<Node<Point>>(getPriorityType(searchStrategy));
        
        frontier.add(new Node<Point>(start, null));
        HashSet<Node<Point>> explored_set = new HashSet<Node<Point>>();

        int numNodesExplored = 0;
        Node<Point> current = null;
        while (!frontier.isEmpty()) {
            current = frontier.remove();
            numNodesExplored++;
            if (current.item.equals(goal)) break; // goal check
            explored_set.add(current);
            
            if (!current.item.equals(start) && !current.item.equals(goal))
                maze[current.item.x][current.item.y] = MARK;
            
            ArrayList<Point> successors = getSuccessors(current.item);
            for (Point neighbor : successors) {
                if (explored_set.contains(new Node<Point>(neighbor, null))) continue;
                Node<Point> node = new Node<Point>(neighbor, current);
                node.current_cost = current.current_cost + 1;
                node.heuristic_cost = Math.abs(goal.x - neighbor.x) + Math.abs(goal.y - neighbor.y);
                initCost(searchStrategy, node);
                frontier.add(node);
            }
        }
        System.out.println("Num nodes explored = " + numNodesExplored);
        
        printAndCleanMaze();
        
        if (current != null && current.item.equals(goal)) {
            while (current.parent != null) {
                current = current.parent;
                if (current.parent == null) break;
                maze[current.item.x][current.item.y] = MARK;
            }
        }
        printAndCleanMaze();
    }
    
    private void printAndCleanMaze() {
        System.out.println();
        for (int i = 0; i < row_num; i++) {
            for (int j = 0; j < col_num; j++) {
                System.out.print(maze[i][j]);
                if (maze[i][j] == MARK) maze[i][j] = EMPTY;
            }
            System.out.println();
        }
        System.out.println();
    }
    
    public static void main(String[] args) {
        String maze_file = "smallMaze.txt";
        if (args.length >= 1)
            maze_file = args[0];
        
        MazeSearch mazeSearch = new MazeSearch(maze_file);
        System.out.println("Doing DFS Search");
        mazeSearch.searchPath("dfs");
        System.out.println();

        System.out.println("Doing BFS Search");
        mazeSearch.searchPath("bfs");
        System.out.println();
        
        System.out.println("Doing Greedy Search");
        mazeSearch.searchPath("greedy");
        System.out.println();
        
        System.out.println("Doing ASTAR Search");
        mazeSearch.searchPath("astar");
        System.out.println();
    }
}
